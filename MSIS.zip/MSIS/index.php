<?php
session_start();
if (!isset($_SESSION['username']) && !isset($_SESSION['pass'])) {
    echo "<script>alert('You redirected to login page, please enter username and password.');window.location.href = 'login.php';</script>";
}
if (isset($_POST['logout'])) {
    session_destroy();
    echo "<script>alert('Thank you for using our System!.');window.location.href = 'login.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Marber Student Information System</title>
    <meta name="robots" content="noindex, nofollow">
    <meta charset="utf-8">
    <link rel="icon" type="image/gif" href="Images/marber.png">
    <meta name="description" content="Student Management System">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <link href="css/dash.css" rel="stylesheet">

    <script>
        $(document).ready(function() {
            $('#sidebarCollapse').on('click', function() {
                $('#sidebar').toggleClass('active');
            });
        });

        function submitLogout() {
            document.postlink.submit();
        }
    </script>

</head>

<!-- A HREF TO POST REQUEST -->
<form name=postlink method="POST">
    <input type="hidden" name="logout">
</form>

<body class="fm-login-page" oncontextmenu="return false">
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <img class="ml-4" style="width:150px;mix-blend-mode: multiply;" src="Images/marber.png">
                <h3>Marber Student Information System</h3>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="?"><i class="fa fa-user mr-3"></i> Dashboard</a>
                </li>

                <li>
                    <a href="?studentlist&reports"><i class="fa fa-address-card-o mr-3"></i>Report</a>
                </li>
            </ul>



        </nav>

        <!-- Side Navigation Bar of the system-->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-info pull-left">
                        <i class="fa fa-bars"></i>
                        <span>Close</span>
                    </button>


                    <div class="collapse navbar-collapse justify-content-md-center">
                        <?php if (isset($_GET['studentlist']) && isset($_GET['edit'])) { ?>
                            <h5 class="ml-auto">Edit Student</h5>
                        <?php } elseif (isset($_GET['studentlist']) && isset($_GET['addnew'])) { ?>
                            <h5 class="ml-auto">Add New Student</h5>
                        <?php } else {
                        } ?>


                    </div>

                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">



                            <li class="nav-item active">

                            <a class="dropdown-item" href="#"> <i class="fa fa-user-circle-o"></i> <?php echo $_SESSION['username'];?></a>

                            </li>

                            <li>
                                <a class="dropdown-item" href="#" onclick="submitLogout()"><i class="fa">&#xf08b;</i> Logout</a>
                            </li>


                        </ul>
                    </div>



                </div>
            </nav>

            <!-- main content of the system -->
            <div class="container-mg">
                <?php

                function check_exist($value)
                {
                    include("DB/conn.php");
                    $user = mysqli_real_escape_string($DB, $value);
                    $result = mysqli_query($DB, "SELECT COUNT(*) AS num_studentid FROM students WHERE studentid='{$user}' LIMIT 1;");
                    $row = mysqli_fetch_array($result);
                    if ($row["num_studentid"] > 0) {
                        $school_code = "3042";
                        $value = $school_code . rand(10, 1000);
                        return $value;
                    } else {
                        return $value;
                    }
                }


                function edit_student_data($studentid)
                {
                    include("DB/conn.php");
                    $result = $conn->query("SELECT * FROM students WHERE studentid='$studentid'");
                    $students = $result->fetch_all(MYSQLI_ASSOC);
                    return $students;
                }

                include("add.php");
                include("pages.php");
                include("edit_student.php");

                ?>

            </div>




    
            <!-- pagination -->

            <script>
                getPagination('#table-id');

                function getPagination(table) {
                    var lastPage = 1;

                    $('#maxRows')
                        .on('change', function(evt) {

                            lastPage = 1;
                            $('.pagination')
                                .find('li')
                                .slice(1, -1)
                                .remove();
                            var trnum = 0;
                            var maxRows = parseInt($(this).val());

                            if (maxRows == 5000) {
                                $('.pagination').hide();
                            } else {
                                $('.pagination').show();
                            }

                            var totalRows = $(table + ' tbody tr').length; // numbers of rows
                            $(table + ' tr:gt(0)').each(function() {
                                // each TR in  table and not the header
                                trnum++; // Start Counter
                                if (trnum > maxRows) {
                                    // if tr number gt maxRows

                                    $(this).hide(); // fade it out
                                }
                                if (trnum <= maxRows) {
                                    $(this).show();
                                } // else fade in Important in case if it ..
                            }); //  was fade out to fade it in
                            if (totalRows > maxRows) {
                                // if tr total rows gt max rows option
                                var pagenum = Math.ceil(totalRows / maxRows); // ceil total(rows/maxrows) to get ..
                                //	numbers of pages
                                for (var i = 1; i <= pagenum;) {
                                    // for each page append pagination li
                                    $('.pagination #prev')
                                        .before(
                                            '<li data-page="' +
                                            i +
                                            '">\
              <span>' +
                                            i++ +
                                            '<span class="sr-only">(current)</span></span>\
            </li>'
                                        )
                                        .show();
                                } // end for i
                            } // end if row count > max rows
                            $('.pagination [data-page="1"]').addClass('active'); // add active class to the first li
                            $('.pagination li').on('click', function(evt) {
                                // on click each page
                                evt.stopImmediatePropagation();
                                evt.preventDefault();
                                var pageNum = $(this).attr('data-page'); // get it's number

                                var maxRows = parseInt($('#maxRows').val()); // get Max Rows from select option

                                if (pageNum == 'prev') {
                                    if (lastPage == 1) {
                                        return;
                                    }
                                    pageNum = --lastPage;
                                }
                                if (pageNum == 'next') {
                                    if (lastPage == $('.pagination li').length - 2) {
                                        return;
                                    }
                                    pageNum = ++lastPage;
                                }

                                lastPage = pageNum;
                                var trIndex = 0; // reset tr counter
                                $('.pagination li').removeClass('active'); // remove active class from all li
                                $('.pagination [data-page="' + lastPage + '"]').addClass('active'); // add active class to the clicked
                                // $(this).addClass('active');					// add active class to the clicked
                                limitPagging();
                                $(table + ' tr:gt(0)').each(function() {
                                    // each tr in table not the header
                                    trIndex++; // tr index counter
                                    // if tr index gt maxRows*pageNum or lt maxRows*pageNum-maxRows fade if out
                                    if (
                                        trIndex > maxRows * pageNum ||
                                        trIndex <= maxRows * pageNum - maxRows
                                    ) {
                                        $(this).hide();
                                    } else {
                                        $(this).show();
                                    } //else fade in
                                }); // end of for each tr in table
                            }); // end of on click pagination list
                            limitPagging();
                        })
                        .val(500)
                        .change();

                    // end of on select change

                    // END OF PAGINATION
                }

                function limitPagging() {
                    // alert($('.pagination li').length)

                    if ($('.pagination li').length > 10) {
                        if ($('.pagination li.active').attr('data-page') <= 3) {
                            $('.pagination li:gt(5)').hide();
                            $('.pagination li:lt(5)').show();
                            $('.pagination [data-page="next"]').show();
                        }
                        if ($('.pagination li.active').attr('data-page') > 3) {
                            $('.pagination li:gt(0)').hide();
                            $('.pagination [data-page="next"]').show();
                            for (let i = (parseInt($('.pagination li.active').attr('data-page')) - 2); i <= (parseInt($('.pagination li.active').attr('data-page')) + 2); i++) {
                                $('.pagination [data-page="' + i + '"]').show();

                            }

                        }
                    }
                }

                $(function() {
                    // Just to append id number for each row
                    $('table tr:eq(0)').prepend('<th style="width:50px;"> No </th>');

                    var id = 0;

                    $('table tr:gt(0)').each(function() {
                        id++;
                        $(this).prepend('<td>' + id + '</td>');
                    });
                });

                //  Developed By Yasser Mas
                // yasser.mas2@gmail.com
            </script>

            <!-- Copyright -->

            <!-- Copyright -->

        </div>
    </div>
</body>

</html>