<?php
$request = $_REQUEST;
$studentid = $request['studentid'];
$lastname = $request['lastname'];
$firstname = $request['firstname'];
$middlename = $request['middlename'];
$email = $request['email'];
$phonenumber = $request['phonenumber'];
$dateofbirth = $request['birthdate'];
$gender = $request['gender'];
$address = $request['address'];
$level = $request['gradelevel'];

$date_created = date("m/d/Y");

include("DB/conn.php");

	// Set the INSERT SQL data
    $sql = "UPDATE students SET 
    Firstname = '" . $firstname . "',
    Middlename = '" . $middlename . "', 
    Lastname = '" . $lastname . "',
    student_email = '" . $email . "',
    student_number = '" . $phonenumber . "',
    BOD = '" . $dateofbirth . "',
    Gender = '" . $gender . "',
    Address = '" . $address . "',
    Level = '" . $level . "',
    date_created = '" . $date_created . "'
    WHERE (`studentid` = '" . $studentid . "');";

	// Process the query so that we will save the date of birth
	if ($conn->query($sql)) {
	  echo "Student has been sucessfully updated.";
	} else {
	  return "Error: " . $sql . "<br>" . $conn->error;
	}

	// Close the connection after using it
	$conn->close();
?>