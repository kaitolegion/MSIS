
<div class="modal fade" id="edit-student-modal">
        <div class="modal-dialog modal-lg">
    
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Edit Student</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
    
                <form action="update.php" enctype="multipart/form-data" id="edit-form" >
                   <div class="row mb-3">
                      <div class="col">
                         <label for="">Update Photo</label>
                         <input type="file" name="file" class="form-control">
                      </div>
                      <div class="col">
                         <label for="">Student Photo</label>
                         <img  name="photoimage" class="ml-4" style="width:110px; height:110px; border-radius:100%;border:2px solid black;">
                      </div>
    
                   </div>
                   <div class="row mb-3">
    
                      <div class="col">
                         <input class="form-control" type="text" name="studentid" readonly>
                      </div>
    
                      <div class="col">
                         <input type="text" name="lastname" placeholder="Lastname" class="form-control">
                      </div>
    
                      <div class="col">
                         <input type="text" name="firstname" placeholder="Firstname" class="form-control">
                      </div>
    
                      <div class="col">
                         <input type="text" name="middlename" value="" placeholder="Middlename" class="form-control">
                      </div>
                   </div>
    
                   <div class="row mb-3">
                      <div class="col">
                         <input class="form-control" type="text" name="email">
                      </div>
    
                      <div class="col">
                         <input type="tel" name="phonenumber" value="" placeholder="Phone Number" class="form-control">
                      </div>
                   </div>
    
                   <div class="row mb-3">
    
                      <div class="col">
                         <input type="date" name="birthdate" value="" placeholder="" class="form-control">
                      </div>
    
                      <div class="col form-group">
                         <select name="gender" class="form-control">
                            <option value="">- Select Gender -</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                         </select>
                      </div>
    
                   </div>
    
    
                   <div class="row mb-3">
    
                      <div class="col">
                         <input type="text" name="address" placeholder="Street, City, Province, zipcode" class="form-control">
                      </div>
                      

                   </div>
    
                   <div class="row mb-3">
    
                      <div class="col form-group">
                         <select name="gradelevel" class="form-control">
                            <option value="None">- Select Grade Level -</option>
                            <option value="GRADE 7">Grade 7</option>
                            <option value="GRADE 8">Grade 8</option>
                            <option value="GRADE 9">Grade 9</option>
                            <option value="GRADE 10">Grade 10</option>
                            <option value="GRADE 11">Grade 11</option>
                            <option value="GRADE 12">Grade 12</option>
                         </select>
                      </div>

                      <div class="col">
                         <input type="text" name="datecreated"  class="form-control" readonly>
                      </div>
    
                   </div>
    
                </form>
    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btnUpdateSubmit">Update</button>
                    <button type="button" class="btn btn-danger float-right" id="btnDeleteStudent" >Delete</button>
                    <button type="button" class="btn btn-danger float-right" data-dismiss="modal">Close</button>
                </div>
            </div>


    
        </div>
    </div>
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>


           

function deletedata(){
   $("#btnDeleteStudent").on("click", function() {
		 var $this = $(this); 
        var $caption  = $this.html();
        var form 	= "#edit-form"; 
        var formData = $(form).serializeArray(); 

    	$.ajax({
	        type: "POST", 
	        url: "delete.php", 
	        data: formData,
   
	        beforeSend: function () {
	            $this.attr('disabled', true).html("Processing...");
	        },
	        success: function (response) {
	            $this.attr('disabled', false).html($caption);
	            all();
               resetForm(form);
               window.location.href = 'index.php?studentlist&reports';
	            
	        },
        
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        }
	    }).done(function(data) {
          
          alert(data);
       });
	});
}


function all() 
{
	// Ajax config
	$.ajax({
        type: "GET",
        url: 'all.php',
        success: function (response) {
         
        	response = JSON.parse(response);


        }
    });
}


function resetForm(selector) 
{
	$(selector)[0].reset();
}


function get() 
{
	$(document).delegate("[data-target='#edit-student-modal']", "click", function() {

		var Id = $(this).attr('data-id');
		var Photofilename = $(this).attr('data-photo');

		$.ajax({
	        type: "GET",
	        url: 'get.php', 
	        data: {studentid:Id},
	        beforeSend: function () {
	            
	        },
	        success: function (response) {
	            response = JSON.parse(response);
             
               
	            $("#edit-form [name=\"studentid\"]").val(response.studentid);
	            $("#edit-form [name=\"lastname\"]").val(response.Lastname);
	            $("#edit-form [name=\"firstname\"]").val(response.Firstname);
	            $("#edit-form [name=\"middlename\"]").val(response.Middlename);
	            $("#edit-form [name=\"email\"]").val(response.student_email);
	            $("#edit-form [name=\"phonenumber\"]").val(response.student_number);
	            $("#edit-form [name=\"birthdate\"]").val(response.BOD);
	            $("#edit-form [name=\"gender\"]").val(response.Gender);
	            $("#edit-form [name=\"address\"]").val(response.Address);
	            $("#edit-form [name=\"gradelevel\"]").val(response.Level);
               $("#edit-form [name=\"datecreated\"]").val(response.date_created);

               $("#edit-form [name=\"photoimage\"]").attr("src","Images/photos/"+response.Picture);

	        }
	    });
	});
}




function update() 
{

	$("#btnUpdateSubmit").on("click", function() {
		 var $this 		    = $(this); 
        var $caption        = $this.html();
        var form 			= "#edit-form"; 
        var formData        = $(form).serializeArray(); 
        var route 			= $(form).attr('action'); 
        
        var fd = new FormData(document.getElementById("edit-form"));
        fd.append("label", "MSIS-");
         $.ajax({
              url: "upload_img.php",
              type: "POST", 
              data: fd,
              processData: false,  
              contentType: false   
            })
            
            .done(function(data) {
          alert(data);
       });



    	$.ajax({
	        type: "POST", 
	        url: route, 
	        data: formData,
   
	        beforeSend: function () {
	            $this.attr('disabled', true).html("Processing...");
	        },
	        success: function (response) {
	            $this.attr('disabled', false).html($caption);
	            all();
	            resetForm(form);
               window.location.href = 'index.php?studentlist&reports';

	            $('#edit-student-modal').modal('toggle');
	        },
        
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	        	
	        }
	    }).done(function(data) {
          alert(data);
       });
	});



}


$(document).ready(function() {

	
	all();
	get();
	update();
   deletedata();
});
</script>