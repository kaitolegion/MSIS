<?php


$label = $_POST["label"];
$studentid = $_POST["studentid"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if (in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "\n";
    } else {
        $filename = $label.$_FILES["file"]["name"];

        if (file_exists("Images/photos/" . $filename)) {
            echo $filename . " already exists. ";
        } else {
            move_uploaded_file($_FILES["file"]["tmp_name"],
            "Images/photos/" . $filename);
            include("DB/conn.php");
            $sql = "UPDATE students SET 
            Picture = '" . $filename . "' WHERE (studentid = '" . $studentid . "');";
    
            if ($conn->query($sql)) {
              echo "Change picture successfully.";
            } 

        }
    }
} else {
    echo "$filename Invalid file";
}




   




?>