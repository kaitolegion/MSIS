<?php
$server = "localhost";
$username = "root";
$pass = "";
$database = "msis";

$conn = new mysqli($server,$username,$pass,$database);
$DB =  mysqli_connect($server,$username,$pass,$database);


if ($conn->connect_error){  die("Connection failed".$conn->connect_error); }


?>