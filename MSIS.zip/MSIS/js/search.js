$("#search").keyup(function() {
    var regex = new RegExp($("#search").val(), "i");
    var rows = $("table tr:gt(0)");
    rows.each(function (index) {
      lastname = $(this).children("#searchme").html()
      firstname= $(this).children("#searchme2").html()
      middlename= $(this).children("#searchme3").html()
      studentid= $(this).children("#searchme4").html()

      if (lastname.search(regex) != -1) {
        $(this).show();
      } else if(firstname.search(regex) != -1){
        $(this).show();
      } else if(middlename.search(regex) != -1){
        $(this).show();
      } else if(studentid.search(regex) != -1){
        $(this).show();
      }
      else {
        $(this).hide();
      }
    });
  });