-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2023 at 12:43 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `instructor_id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`instructor_id`, `username`, `password`, `email`) VALUES
(12, 'kaito', 'kaito', 'artjaygeneralao123@gmail.com'),
(13, 'matt', 'matt', 'mattjacobgarsuta@gmail.com'),
(14, 'geovar', 'geovar', 'geovarkierklatonio@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentid` int(7) NOT NULL,
  `Picture` varchar(45) DEFAULT NULL,
  `Firstname` varchar(45) DEFAULT NULL,
  `Middlename` varchar(45) DEFAULT NULL,
  `Lastname` varchar(45) DEFAULT NULL,
  `student_email` varchar(45) DEFAULT NULL,
  `student_number` varchar(45) DEFAULT NULL,
  `BOD` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `Level` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `instructor_id` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentid`, `Picture`, `Firstname`, `Middlename`, `Lastname`, `student_email`, `student_number`, `BOD`, `Gender`, `Address`, `Level`, `date_created`, `instructor_id`) VALUES
(304231, 'Genovia.jpg', 'Abigail', 'Limsan', 'Genovia', 'abigailgenovia376@gmail.com', '09702646764', '2006-03-07', 'Female', 'Kinuskusan, Bansalan Davao del Sur', 'GRADE 11', '01/15/2023', '12'),
(304287, 'Canono.jpg', 'Maria Nina', 'Cagape', 'Canono', 'ninyacanono09@gmail.com', '09308389394', '2006-01-04', 'Female', 'Alegre, Bansalan, Davao del Sur', 'GRADE 11', '01/15/2023', '12'),
(304288, 'Naraga.jpg', 'Nicole', 'Tinguha', 'Naraga', 'naraganicoletinguha@gmail.com', '09268514987', '2006-05-15', 'Female', 'Altavista, Bansalan Davao del Sur', 'GRADE 11', '01/15/2023', '12'),
(304289, 'Tabacon.jpg', 'Joerissa', 'Relator', 'Tabacon', 'joerissatabacon71@gmail.com', '09675410294', '2006-08-03', 'Female', 'Altavista, Bansalan, Davao del Sur', 'GRADE 11', '01/07/2023', '13'),
(304290, 'Giangan.jpg', 'Steve Irwin', 'Baring', 'Giangan', 'steveirwingaingan@gmail.com', '09480263268', '2005-01-08', 'Male', 'New Opon, Magsaysay, Davao del Sur', 'GRADE 11', '01/07/2023', '13'),
(304291, 'Pantollano.jpg', 'Owen June', 'Segundo', 'Pantollano', 'owenjunepantollano@gmail.com', '09553555623', '2006-06-15', 'Male', 'Brgy. Sto. Nino, Bansalan, Davao del Sur', 'GRADE 11', '01/07/2023', '13'),
(304292, 'Socon.jpg', 'Jasmin', 'Ano', 'Socon', 'Soconjasmin@gmail.com', '09382999867', '2006-10-12', 'Female', 'Brgy. New Opon, Magsaysay, Davao del Sur', 'GRADE 11', '01/07/2023', '14'),
(304293, 'Geolagon.jpg', 'Elaiza', 'Maranas', 'Geolagon', 'elaizageolagon7@gmail.com', '09515737832', '2006-06-18', 'Female', 'Brgy. New Opon, Magsaysay, Davao del Sur', 'GRADE 11', '01/07/2023', '14'),
(304294, 'Baylosis.jpg', 'Mary Kaye', 'Gomera', 'Baylosis', 'marykayebaylosis@gmail.com', '09070435158', '2006-03-19', 'Female', 'Darapuay, Bansalan, Davao del Sur', 'GRADE 11', '01/07/2023', '14'),
(304295, 'Castro.jpg', 'Angel', 'Castro', 'Omero', 'omerotuday@gmail.com', '09817785486', '2005-12-12', 'Female', 'Magsaysay, Bansalan, Davao del Sur', 'GRADE 11', '01/15/2023', '14'),
(3042442, 'MSIS-Illuka.jpg', 'Zoldick', 'Hunter', 'Illuka', 'illukazoldick@gmail.com', '092342344', '2007-06-30', 'Female', 'NONE, NONE, NONE, 09234', 'GRADE 7', '01/15/2023', '13'),
(3042521, 'MSIS-Princess.jpg', 'Sophia', 'Cute', 'Princess', 'princesssophia@gmail.com', '0121993213', '2023-01-14', 'Female', 'NONE, NONE, NONE, 1213', 'GRADE 7', '01/15/2023', '13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`instructor_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
