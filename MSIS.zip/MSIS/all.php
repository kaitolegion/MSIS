<?php
if (true) {
  echo "<script>window.location.href = 'login.php';</script>";
} 
include("DB/conn.php");

if ($conn->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
  }

  // Set the INSERT SQL data
  $sql = "SELECT * FROM students";

  // Process the query so that we will save the date of birth
  $results = $conn->query($sql);

  // Fetch Associative array
  $row = $results->fetch_all(MYSQLI_ASSOC);

  // Free result set
  $results->free_result();

  // Close the connection after using it
  $conn->close();

?>