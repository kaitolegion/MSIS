<?php
session_start();
error_reporting(0);
ini_set("memory_limit", -1);
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Access-Control-Allow-Origin: *");
?>


<html>

<head>
  <title>MSIS - Login</title>
  <link rel="icon" type="image/gif" href="Images/marber.png">
  <meta name=viewport content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="description" content="Marber School Information System">
  <link rel="stylesheet" href="Bootstrap/min.css" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script type="text/javascript" src="js/showhidepass.js"></script>
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>
  <style>
    body {
      padding: 100px 0;
    }

    h4 {
      text-align: center;
    }

    a,
    a:hover {
      color: #333;
    }
  </style>

  <div class="col d-flex justify-content-center">
    <div class="login">
      <div class="mt-2 mb-4">
        <img class="ml-4" style="width:260px;height:200px;mix-blend-mode: multiply;" src="Images/marber.png">
        <h4>M.S.I.S Login</h4>
      </div>
      <form method="POST" action="login.php">
        <div class="form-group d-flex justify-content-center">
          <input type="text" class="form-control" name="username" placeholder="Email/Username">
        </div>


        <div class="form-group">
          <div class="input-group" id="show_hide_password">
            <input type="password" class="form-control" name="pass" placeholder="Password" id="pwd">
            <div class="input-group-append">
              <a href="" class="input-group-text">
                <i class="fa fa-eye-slash" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </div>








        <div class="form-group d-flex justify-content-center">
          <input name="submit" type="submit" class="form-control btn-success" value="login">
        </div>

        <div class="form-group d-flex justify-content-center">
          <a href="#" id="reset" data-toggle="modal">Forgot password? Click here</a>
          <!-- data-target="#myModal" data-toggle="modal" -->
        </div>

      </form>
    </div>
  </div>


  <!-- Modal dialog for reset pass -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4>Forgot password</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p>To reset your password please enter your registered email</p>
          <form>
            <input type="email" name="email" placeholder="Enter email" class="form-control">
            <input type="submit" name="reset" class="mt-2 ml-1 btn btn-info" value="Reset Password">
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>








  <script>
    $(document).on('click', '#reset', function(e) {
      swal({
        title: 'Submit email to reset password',
        input: 'email',
        inputPlaceholder: 'Example@email.xxx',
        showCancelButton: true,
        confirmButtonText: 'Submit',
        showLoaderOnConfirm: true,
        preConfirm: (email) => {
          return new Promise((resolve) => {
            setTimeout(() => {
              if (email != 'kaito@gmail.com') {
                swal.showValidationError(
                  'This email is not register.'
                )
              }
              resolve()
            }, 2000)
          })
        },
        allowOutsideClick: false
      }).then((result) => {



        if (result.value) {
          swal({
            type: 'success',
            title: 'Check your email for reset link',
            html: 'An email has been sent to: ' + result.value
          })
        }




      })
    });
  </script>






  <footer class="text-center text-lg-start bg-white text-muted fixed-bottom">
    <!-- Copyright -->
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.025);">
      © 2022 Copyright:
      <a class="text-reset fw-bold" href="https://github.com/kaitolegion">Covid Developer</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
  </body>

</html>




<?php

if (isset($_SESSION['username'])) {
  echo "<script>alert('You are already login');window.location.href = 'index.php';</script>";
} else if(isset($_SESSION['email'])){
  echo "<script>alert('You are already login');window.location.href = 'index.php';</script>";
}

// login credentials connect to database
include("DB/conn.php");
if (isset($_POST['submit'])) {
  $myusername = mysqli_real_escape_string($DB, $_POST['username']);
  $mypassword = mysqli_real_escape_string($DB, $_POST['pass']);

  $sql = "SELECT instructor_id FROM instructor where username='$myusername' and password='$mypassword'";
  $sqll = "SELECT instructor_id FROM instructor where email='$myusername' and password='$mypassword'";
  $user_result = mysqli_query($DB, $sql);
  $email_result = mysqli_query($DB, $sqll);

  $row = mysqli_fetch_array($user_result, MYSQLI_ASSOC);
  $row2 = mysqli_fetch_array($email_result, MYSQLI_ASSOC);
  $active = $row['active'];
  $active = $row2['active'];

  $count = mysqli_num_rows($user_result);
  $count2 = mysqli_num_rows($email_result);
  // login

  // this is for username and password
  if ($count == 1) {
    $_SESSION["username"] = $_REQUEST['username'];
    $_SESSION["pass"] = $_REQUEST['pass'];
    $_SESSION["instructor"] = $row["instructor_id"];
    echo "<script>alert('Login success username');window.location.href = 'index.php';</script>";

    // this is for email and password
  } else if ($count2 == 1) {
    $_SESSION["username"] = $_REQUEST['username'];
    $_SESSION["pass"] = $_REQUEST['pass'];
    echo "<script>alert('Login success email');window.location.href = 'index.php';</script>";
  }

  // this is invalid alert page
  else {
    echo "<script>

      </script>";
  }
}




?>