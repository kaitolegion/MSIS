<?php 

$school_code = "3042";
$num = $school_code.rand(10,1000);
$date_created = date("m/d/Y");

include("DB/conn.php");

   if (isset($_POST['add'])) {


      $studentid = $_POST['studentid'];
      $lastname = $_POST['lastname'];
      $firstname = $_POST['firstname'];
      $middlename = $_POST['middlename']; // optional
      $email = $_POST['email'];
      $phonenumber = $_POST['phonenumber'];
      $birthdate = $_POST['birthdate'];
      $gender = $_POST['gender'];

      $inst = $_POST['instructor_id'];  // instructor id
      
      $street = $_POST['street'];
      $city = $_POST['city'];
      $province = $_POST['province'];
      $zipcode = $_POST['zipcode'];

      $address_format = "$street, $city, $province, $zipcode";
      
      $gradelevel = $_POST['gradelevel'];


      if (
         !empty($studentid) &&
         !empty($inst) &&
         !empty($lastname) &&
         !empty($firstname) &&
         !empty($middlename) &&
         !empty($email) &&
         !empty($phonenumber) &&
         !empty($birthdate) &&
         !empty($gender) &&
         !empty($address_format) &&
         !empty($gradelevel)
          
          ) {

            $photo = $_FILES['photo']['name']; // optional
            
           
            if (!empty($photo)) {
                    $stu_filename = explode('.',$photo);
                    $photo_extension = end($stu_filename);

                    if ($photo_extension == 'jpg' || $photo_extension == 'png' || $photo_extension == 'jpeg') {
                      $imagefilename = "MSIS-".$lastname.".".$stu_filename[1];
                      move_uploaded_file($_FILES['photo']['tmp_name'],'Images/photos/'.$imagefilename);
                       // execute query

                       $q = "INSERT INTO students (`studentid`, `Picture`, `Firstname`, `Middlename`, `Lastname`, `student_email`, `student_number`, `BOD`, `Gender`, `Address`, `Level`, `date_created`, `instructor_id`) VALUES ('$studentid', '$imagefilename', '$firstname', '$middlename', '$lastname', '$email', '$phonenumber','$birthdate', '$gender', '$address_format', '$gradelevel','$date_created', '$inst');";
                       if ($conn->query($q) === TRUE) {
                        echo "<script>alert('Upload && added successfully');window.location.href = 'index.php?studentlist&reports';</script>";
                      } else {
                        echo "<script>alert('Error updating record');</script> ";
                      }
                     }
            } else{
                     $defaultimagefilename = "marber.png"; // default picture
                     $q = "INSERT INTO students (`studentid`, `Picture`, `Firstname`, `Middlename`, `Lastname`, `student_email`, `student_number`, `BOD`, `Gender`, `Address`, `Level`, `date_created`, `instructor_id`) VALUES ('$studentid', '$defaultimagefilename', '$firstname', '$middlename', '$lastname', '$email', '$phonenumber','$birthdate', '$gender', '$address_format', '$gradelevel','$date_created', '$inst');";
                     $conn->query($q);
                     echo "<script>alert('added successfully');window.location.href = 'index.php?studentlist&reports';</script>"; 
               }
            
         
      } else {
           echo "<script>alert('cannot add input is empty')</script>";
      }

   }



?>


<div class="modal fade" id="myModalAddStudents" role="dialog">
   <div class="modal-dialog modal-lg">

      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header">
            <h4>Add new student</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
         </div>
         <div class="modal-body">


            <form method="POST" enctype="multipart/form-data">
               <div class="row mb-3">
                  <div class="col">
                     <label for="">Student Photo</label>
                     <input type="file" name="photo" class="form-control">
                  </div>

               </div>
               <div class="row mb-3">


                  <div class="col">
                     <input type="text" name="studentid" value="<?php echo check_exist($num);?>" placeholder="Student ID" class="form-control" readonly>
                  </div>

                  <div class="col">
                     <input type="text" name="lastname" placeholder="Lastname" class="form-control">
                  </div>

                  <div class="col">
                     <input type="text" name="firstname" placeholder="Firstname" class="form-control">
                  </div>

                  <div class="col">
                     <input type="text" name="middlename" placeholder="Middlename" class="form-control">
                  </div>
               </div>

               <div class="row mb-3">
                  <div class="col">
                     <input type="email" name="email" placeholder="Email" class="form-control">
                  </div>

                  <div class="col">
                     <input type="tel" name="phonenumber" placeholder="Phone Number" class="form-control">
                  </div>
               </div>

               <div class="row mb-3">

                  <div class="col">
                     <input type="date" name="birthdate" placeholder="" class="form-control">
                  </div>

                  <div class="col form-group">
                     <select name="gender" class="form-control">
                        <option value="">- Select Gender -</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                     </select>
                  </div>

               </div>


               <div class="row mb-3">

                  <div class="col">
                     <input type="text" name="street" placeholder="Street" class="form-control">
                  </div>
                  <div class="col">
                     <input type="text" name="city" placeholder="City" class="form-control">
                  </div>
                  <div class="col">
                     <input type="text" name="province" placeholder="Province" class="form-control">
                  </div>
                  <div class="col">
                     <input type="number" name="zipcode" placeholder="zipcode" class="form-control">
                  </div>


               </div>

               <div class="row mb-3">

                  <div class="col form-group">
                     <select name="gradelevel" class="form-control">
                        <option value="None">- Select Grade Level -</option>
                        <option value="GRADE 7">Grade 7</option>
                        <option value="GRADE 8">Grade 8</option>
                        <option value="GRADE 9">Grade 9</option>
                        <option value="GRADE 10">Grade 10</option>
                        <option value="GRADE 11">Grade 11</option>
                        <option value="GRADE 12">Grade 12</option>
                     </select>
                  </div>

                  <div class="col">
                     <input type="hidden" name="instructor_id" value="<?php echo $_SESSION['instructor'];?>" class="form-control">
                  </div>

                 


               </div>


         </div>
         <div class="modal-footer">
            <input type="submit" name="add" class="mt-2 ml-1 btn btn-info" value="Add">
         </div>


         </form>
      </div>

   </div>
</div>

