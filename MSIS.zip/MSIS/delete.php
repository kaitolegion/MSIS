<?php 


$request = $_REQUEST;
$studentid = $request['studentid'];
if (!isset($studentid)) {
    echo "<script>window.location.href = 'login.php';</script>";
  } 

include("DB/conn.php");
$delete_query = "DELETE FROM students WHERE (studentid = '$studentid')";
if ($conn->query($delete_query) === TRUE ) {
   echo "Delete Successfully";
 } else {
   echo "Delete cancelled";
 }

?>