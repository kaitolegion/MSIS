<?php

	$request = $_REQUEST;
	$studentid = $request['studentid'];

	include("DB/conn.php");

	$sql = "SELECT * FROM students WHERE studentid='".$studentid."'";

	$results = $conn->query($sql);

	$row = $results->fetch_assoc();

	$results->free_result();

	$conn->close();

    if(json_encode($row) == "null"){
        echo "<script>window.location.href = 'login.php';</script>";
    } else{
       echo json_encode($row);
    }
	
?>