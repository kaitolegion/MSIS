<?php
// SECURITY
include('security/xss-safe.php');



// STUDENT LIST
if (isset($_GET['studentlist']) && isset($_GET['reports'])) {
  include("DB/conn.php");
  $intructor = $_SESSION['instructor'];
  $result = $conn->query("SELECT * FROM students WHERE instructor_id = '$intructor'");
  $students = $result->fetch_all(MYSQLI_ASSOC);

  echo '<div class="row" <div class="col ml">
         <div class="form-group ml-3">
             <select class ="form-control" name="state" id="maxRows">
             <option value="5">5</option>
             <option value="10">10</option>
             <option value="20">20</option>
             <option value="50">50</option>
             <option value="500">All</option>
        </select>
         </div>

        
          <div class="form-group has-search ml-2">
               <input type="search" id="search" class="search form-control" onkeyup="mySearch()" placeholder="Search">
          </div>
        <span class="counter pull-right"></span>  
        <div class="col-lg-5 fixed">

        
        <a class="btn btn-danger text-white" data-target="#myModalAddStudents" data-toggle="modal"><i class="fa fa-user-plus"></i> Add</a>
               ';


echo' 
      <button class="btn btn-outline-secondary btn-sm mt-1" id="copy_btn">COPY <i class="fa fa-print"></i></button>
      <button id="printbtn" class="btn btn-outline-secondary btn-sm mt-1" onclick="printDocument();">PRINT <i class="fa fa-print"></i></button>
      <button class="btn btn-outline-secondary btn-sm mt-1" onClick="tableToExel()" id="print-btn">EXCEL <i class="fa fa-print"></i></button>
      ';



      echo ' 
    

      <script type="text/javascript">
      function printDocument() {
              var ww = screen.availWidth;
              var wh = screen.availHeight - 90;
            
      
              var pw = window.open("", "newWin", "width=" + ww + ",height=" + wh);
              pw.document.write(\'<html><title>Printed Page</title><body>\');
              pw.document.write(\'</head><body>\');
              pw.document.write(\'<center><h4>MSIS Student data Report</h4></center>\');
              pw.document.write (\'<table  class="table">\');
              pw.document.write (" <tr>");
              pw.document.write (" <th>Student ID</th>");
              pw.document.write (" <th>FirstName</th>");
              pw.document.write (" <th>MiddleName</th>");
              pw.document.write (" <th>LastName</th>");
              pw.document.write (" <th>Email</th>");
              pw.document.write (" <th>Phone Number</th>");
              pw.document.write (" <th>Birthdate</th>");
              pw.document.write (" <th>Gender</th>");
              pw.document.write (" <th>Address</th>");
              pw.document.write (" <th>Grade Level</th>");
              pw.document.write (" </tr>");';

              foreach ($students as $student) :
                $studentid = $student['studentid'];
                $firstname = $student['Firstname'];
                $middlename = $student['Middlename'];
                $lastname = $student['Lastname'];
                $student_email = $student['student_email'];
                $student_number = $student['student_number'];
            
                $Date = date('Y-m-d', strtotime($student['BOD']));
                $DOB = str_replace("-", "/", $Date);
            
                $Gender = $student['Gender'];
                $Address = $student['Address'];
                $Level = $student['Level'];
               

             echo 'pw.document.write (" <tr>");
              pw.document.write (" <td >'.$studentid.'</td>");
              pw.document.write (" <td>'.$firstname.'</td>");
              pw.document.write (" <td>'.$middlename.'</td>");
              pw.document.write (" <td>'.$lastname.'</td>");
              pw.document.write (" <td>'.$student_email.'</td>");
              pw.document.write (" <td>'.$student_number.'</td>");
              pw.document.write (" <td>'.$DOB.'</td>");
              pw.document.write (" <td>'.$Gender.'</td>");
              pw.document.write (" <td>'.$Address.'</td>");
              pw.document.write (" <td>'.$Level.'</td>");
              pw.document.write (" </tr>");';
            endforeach;


             echo ' pw.document.writeln ("</table>");
              pw.document.write("</body></html>");
              pw.document.close();
              pw.print();
              pw.close();
          }
      </script>';

        


echo '

</div>
</div>

  <style>
  table {
    width:100%
  } th {
    background:#7386D5;
    color:#fff;
  } td {
    padding:5px;
  }
  .tableWrap {
    height: 600px;
    overflow: auto;
  }

  thead tr th {
    position: sticky;
    top: 0;
  }
  </style>
  <div class="tableWrap table-responsive mr-4" onkeydown="return false" onmousedown="return false">
 
 
  <table id="table-id" class="table table-sm results" data-show-header="true" data-pagination="true">
            <thead>
             <tr>
               <th colspan="3">Student ID</th>
               <th>Photo</th>
               <th>Last Name</th>
               <th>First Name</th>
               <th>Middle Name</th>
               <th>Email</th>
               <th>Phone No</th>
               <th>Date of Birth (Y/m/d)</th>
               <th>Gender</th>
               <th>Address</th>
               <th>Level</th>
               <th>Date Created (m/d/Y)</th>
               <th>Options</th>
             </tr>
  </thead>
<tbody id="table-body">';
  foreach ($students as $student) :
    $studentid = $student['studentid'];
    $firstname = $student['Firstname'];
    $middlename = $student['Middlename'];
    $lastname = $student['Lastname'];
    $student_email = $student['student_email'];
    $student_number = $student['student_number'];

    $Date = date('Y-m-d', strtotime($student['BOD']));
    $DOB = str_replace("-", "/", $Date);

    $Gender = $student['Gender'];
    $Address = $student['Address'];
    $Level = $student['Level'];
    $picture = $student['Picture'];
    $date_created = $student['date_created'];


   
    echo '<tr>
          <td id="searchme4" colspan="3" id="id">' . xss_clean($studentid) . '</td>
              <td class="text-center">
                <img style="width:100px; border:solid 2px rgba(0, 0, 0, 0.5); border-radius:100%; height:95px;" src="Images/photos/' . xss_clean($picture) . '">
              </td>
              <td id="searchme">
                <div class="d-flex align-items-center">
                      <span class="ml-2" id="fn" >' . xss_clean($lastname) . '</span>
                </div>
              </td>
              <td id="searchme2">
                <div class="d-flex align-items-center">
                      <span class="ml-2" id="mn">' . xss_clean($firstname) . '</span>
                </div>
              </td>
              <td id="searchme3">
                <div class="d-flex align-items-center">
                       <span class="ml-2" id="ln">' . xss_clean($middlename) . '</span>
                </div>
              </td>
              <td>
                <div class="d-flex align-items-center">
                       <span class="ml-2" id="se">' . xss_clean($student_email) . '</span>
                </div>
              </td>
              <td>
                 <div class="d-flex align-items-center">
                       <span class="ml-2" id="sn">' . xss_clean($student_number) . '</span>
                </div>
              </td>
              <td>
                 <div class="d-flex align-items-center">
                       <span class="ml-2" id="dob">' . xss_clean($DOB) . '</span>
                </div>
              </td>
              <td>
                 <div class="d-flex align-items-center">
                       <span class="ml-2" id="gn">' . xss_clean($Gender) . '</span>
                </div>
              </td>
              <td>
                 <div class="d-flex align-items-center">
                       <span class="ml-2" id="address">' . xss_clean($Address) . '</span>
                </div>
              </td>
              <td>
                 <div class="d-flex align-items-center">
                       <span class="ml-2" id="lvl">' . xss_clean($Level) . '</span>
                </div>
              </td>
              <td>' . xss_clean($date_created) . '</td>
          
              <td><center>
                <a class="btn btn-danger text-white" data-target="#edit-student-modal" data-toggle="modal" data-id="'.$studentid.'"><i class="fa fa-edit"></i></a>
                </center>
              </td>
            </tr>  ';



  endforeach;


  echo '</tbody>
    </table>

    <script src="js/table2excel.js"></script>
    <script>
    function tableToExel(){
      var table2excel = new Table2Excel();
      table2excel.export(document.querySelectorAll("table"));
    }
    </script>

    <script>
    var copyBtn = document.querySelector(\'#copy_btn\');
    copyBtn.addEventListener(\'click\', function () {
      var urlField = document.querySelector(\'table\');
       
      var range = document.createRange();  
      range.selectNode(urlField);
    
      window.getSelection().addRange(range);
       
      document.execCommand(\'copy\');
    }, false);
    
    </script>

    <script type="text/javascript" src="js/search.js"></script>

    </div>
    <div class="pagination-container mt-3 pull-right">
    
    <ul class="pagination">
      <li class="page-item" data-page="prev"><a class="page-link" href="#">Previous</a>
        <span class="sr-only"><a class="page-link" href="#">(current)</a></span>
      </li>

      <li class="page-item" data-page="next"><a class="page-link" href="#">Next</a>
      <span class="sr-only"><a class="page-link" href="#">(current)</a></span>
      </li>
    </ul>
    
</div>


<script>
    var table = "#table-id"
    $("#maxRows").on("change", function(){
       $(".pagination").html()
       var trnum = 0
       var maxRows = parseInt($(this).val())
       var totalRows = $(table+"tbody tr").length
    })
</script>
    ';


} else {

// count total of students in database
$count_students = "select count(*) from students";
$count_instructor = "select count(*) from instructor";
$result = $conn->query($count_students);
$result2 = $conn->query($count_instructor);


  echo "
  <style>
  .counter {
    background-color: #f5f5f5;
    padding: 20px 0;
    border-radius: 5px;
  }
  
  .count-title {
    font-size: 40px;
    font-weight: normal;
    margin-top: 10px;
    margin-bottom: 0;
    text-align: center;
  }
  
  .count-text {
    font-size: 13px;
    font-weight: normal;
    margin-top: 10px;
    margin-bottom: 0;
    text-align: center;
  }
  
  .fa-2x {
    margin: 0 auto;
    float: none;
    display: table;
    color: #4ad1e5;
  }
  
  </style>
   <div class='text-center'>
         <img width='300px' src='Images/marber.png'>

         <div class='container'>
         <div class='row'>
           <br/>
           <div class='col text-center'>
             <h2>Marber Student Information System</h2>
             <span>The Purpose of Marber Student Information SYSTEM OR M.S.I.S is to manage, store and track the student's related data on a secured environment. This system or platform allows the admin to store student's academic records in one place and ensure the only authorized person can access the information.</span>
           </div>
       
         </div>
         <div class='row text-center'>
  
           <div class='col'>
             <div class='counter'>
               <i class='fa fa-book fa-2x'></i>
               <h2 class='timer count-title count-number'>";

               while($row = mysqli_fetch_array($result2))
                            echo $row['count(*)'];
              echo "</h2>
               <p class='count-text '>Instructors</p>
             </div>
           </div>
           <div class='col'>
             <div class='counter'>
               <i class='fa fa-users fa-2x'></i>
               <h2 class='timer count-title count-number'>";
               while($row = mysqli_fetch_array($result))
                            echo $row['count(*)'];
               
             echo " </h2>
               <p class='count-text '>Total Students</p>
             </div>
           </div>
         </div>
       </div>

       <div class='text-center p-4 mt-3' style='background-color: rgba(0, 0, 0, 0.025);'>
       © 2022 Copyright: Coded by
       <a class='text-reset fw-bold' href='https://github.com/kaitolegion'>Covid Developer</a>
   </div>

   </div>
   ";
}
 

